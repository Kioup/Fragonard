angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal

  // Create the login modal that we will use later
  // Triggered in the login modal to close it

  // Perform the login action when the user submits the login form
})

// .controller('PlaylistsCtrl', function($scope) {
//   $scope.playlists = [
//     { title: 'Accueil', id: 1 },
//     { title: 'Carte', id: 2 },
//     { title: 'Quizz', id: 3 },
//     { title: 'Informations', id: 4 }
//   ];
// })

.controller('PlaylistCtrl', function($scope, $stateParams) {
})

.controller('QuizzCtrl', function($scope, $stateParams, $http) {
  $scope.id=$stateParams.categorieId;
  $http({
    method: 'GET',
    url: 'http://127.0.0.1/tests/index.php?categorie='+$scope.id
  }).then(function successCallback(response) {
    $scope.quizz = response.data;
    console.log($scope.quizz);
  });
})

.controller('IsoQuizzCtrl', function($scope, $stateParams, $http) {
    $http({
    method: 'GET',
    url: 'http://127.0.0.1/tests/index.php?categorie='+$stateParams.categorieId+"&id="+$stateParams.isoquizzId
  }).then(function successCallback(response) {
    $scope.isoquizz = response.data;
    console.log($scope.isoquizz);
  });
})

.controller('MapCtrl', function($scope, NgMap, $cordovaGeolocation) {

  $scope.position = {};

  var onSuccess = function(position) {
      $scope.position = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      };
      // console.log(JSON.stringify($scope.position));
  };
  navigator.geolocation.getCurrentPosition(onSuccess, null);

  $cordovaGeolocation.getCurrentPosition()
    .then(function (position) {
      $scope.position = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      };
    }, null);


  NgMap.getMap().then(function(map) {
    $scope.map = map;
  });
});
